let rectX = 0;
let fr = 30; //starting FPS
let clr;




function setup() {
  // put setup code here
  createCanvas(900, 900);
  background(150);
  frameRate(fr);
  clr = color (0, 255, 150);

}
let value = 0
function draw() {
  // put drawing code here
fill(100, 25, 200);
ellipse(200, 350, 350, 200);

  rectX = rectX += 1;

  if (rectX>=width) {
  	if (fr === 30) {
  		clr = color (0, 255, 150);
  		fr = 10;
  		frameRate(fr);
  	} else{
  		clr = color (0, 255, 150);
  		fr = 30;
  		frameRate(fr);
  	}
  	rectX = 0;
  }
  fill(clr);
  rect(rectX, 80, 90, 150);
}
function mousePressed() {
  if (rectX===0) {
    value=255;
  } else {
     rectX = 0;
     clr = color (150, 15, 35);
   }
}