function setup() {
  // put setup code here
 		 createCanvas(1000, 800);
 		 background(185);
  		

}

function draw() {
  
  colorMode(RGB, 255, 255, 255, 1);
 		fill(255, 0, 0);



		strokeWeight(8);
		point(5, 10);
		point(25, 19);
		point(21, 10);
		point(26, 11);
		strokeWeight(8);


 		
 		 ellipse(150, 150, 150, 150);
 		 line(150, 225, 150, 500);

 		 fill(45, 185, 115);
 		 ellipse(300, 300, 150, 150);
 		 line(300, 675, 300, 350);

 		 fill(0,0,200);
 		 quad(250, 350, 450, 460, 400, 500, 250,500);
 		 fill(170, 170, 85);
 		 triangle(950, 600, 750, 650, 950, 790);
 		 line(0, 600, 950, 600);

 		 beginShape(QUADS);
 		 vertex(47,50);
 		 vertex(55, 60);
 		 vertex(65, 70);
 		 vertex(75, 84);
 		 vertext(87, 90);
 		 endShape(CLOSE);
}