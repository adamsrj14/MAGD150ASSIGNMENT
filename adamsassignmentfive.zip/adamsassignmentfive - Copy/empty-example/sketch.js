//clr = color (0, 255, 150);
rectX = 0;
rvalue = 0;
gvalue = 100;
value = 0;
x1 = 25;
y1 = 25;
awidth = 50;
aheight = 50;






function setup() {
  // put setup code here
  createCanvas(1000, 1250);
  background(150);
  colorMode(RGB, 255, 255, 255, 1);
}


function draw() {
  fill(rvalue, gvalue, 0, 1);
  rect(x1, y1, awidth, aheight);

  fill(125, 125, 15, 1);
  rect(150, 150, 650, 600);

  fill(240, 200, 0, 1);
  rect(250, 800, 50, 30);

  fill(100, 150, 200, 1);
  rect(375, 800, 50, 30);

  fill(50);
  rect(840, 250, 60, 20);

  fill(50);
  rect(840, 300, 60, 20);

  fill(0, 255, 0);
  circle(700, 910, 100);

  fill(255, 0, 100);
  circle(570, 850, 85);

  fill(0, 0, 230);
  circle(500, 355, 80);

  line(500, 395, 500, 600);

  fill(150);
  ellipse(475, 650, 600, 50);

  fill(20);
  ellipse(475, 200, 600, 35);


}







function mousePressed() {

  if ((value === 0) && (mouseX > x1) && (mouseX < x1+awidth) && (mouseY > y1) && (mouseY < y1+aheight)){
 
    rvalue = 255;
    gvalue = 0;

   if (value === 0) {

    value = 255;

    } else {

      value = 0;

    }


  } else {

    rvalue = 0;
    gvalue = 0;
    value = 0;

  }



}

