let rectX = 0;
let fr = 30;
let clr;

function setup() {
  // put setup code here

  angleMode(RADIANS);

  createCanvas(800, 800);

  background(200);

  frameRate(fr);
  clr = color(255, 0, 0)

  colorMode(RGB, 255);

}

function draw() {
  // put drawing code here
  rectX = rectX += 1;

if (rectX >= width) {
  if (fr === 30) {
    clr = color(0, 0, 255);
    fr = 10;
    
  }
}
  let z =mouseX;
  print(mouseX, mouseY, mouseX, mouseY);
  line(pmouseX, pmouseY, pmouseX, pmouseY);

 fill(200, 150, 50);

 triangle(400, 400, 300, 300, 350, 350);

  ellipse(rectX, 50, 80, 80);

  fill(250, 0, 180);

  square(250, 220, 55);

  fill(100, 250, 150);

  ellipse(350, 350, 65);

  line(z, 0, z, 200);

line(200, mouseY, 400, mouseY);

}
